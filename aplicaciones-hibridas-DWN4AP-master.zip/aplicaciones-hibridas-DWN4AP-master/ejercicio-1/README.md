# Ejercicio 1

Este proyecto es un ejemplo básico de un proyecto Node.js que verifica si un número es primo.

## Requisitos

- Node.js instalado

## Instalación

1. Clonar el repositorio.
2. Ejecutar `npm install` para instalar las dependencias.

## Uso

1. Configurar el archivo `.env` con el número que desea verificar.
2. Ejecutar el script con `npm start`.
